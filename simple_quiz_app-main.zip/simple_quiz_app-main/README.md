# simple_quiz_app
Fetches questions from firebase's realtime database and show them to user.
in the end, shows the result of the quiz.

